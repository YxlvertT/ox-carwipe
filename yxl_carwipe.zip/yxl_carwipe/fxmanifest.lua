fx_version 'cerulean'
game 'gta5'

author 'yxl'
description 'Automatic vehicle cleanup / tow system using ox_lib notifications'
version '1.0.0'

lua54 'yes'

server_scripts {
    'server/main.lua',
}